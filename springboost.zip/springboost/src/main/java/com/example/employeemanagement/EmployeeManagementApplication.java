package com.example.employeemanagement;

import com.example.employeemanagement.entity.Employee;
import com.example.employeemanagement.repository.EmployeeRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;

import java.io.InputStream;
import java.util.List;

@SpringBootApplication
public class EmployeeManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(EmployeeRepository employeeRepository, ObjectMapper objectMapper) {
        return args -> {
            if (employeeRepository.count() == 0) {
                TypeReference<List<Employee>> typeReference = new TypeReference<List<Employee>>() {};
                InputStream inputStream = new ClassPathResource("employees.json").getInputStream();
                try {
                    List<Employee> employees = objectMapper.readValue(inputStream, typeReference);
                    employeeRepository.saveAll(employees);
                    System.out.println("Successfully seeded " + employees.size() + " employees from employees.json!");
                } catch (Exception e) {
                    System.out.println("Unable to save employees: " + e.getMessage());
                }
            }
        };
    }
}
